echo "I am running: $0"
